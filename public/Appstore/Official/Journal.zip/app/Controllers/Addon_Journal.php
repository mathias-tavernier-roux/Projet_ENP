<?php

namespace App\Controllers;

class Addon_Journal extends BaseController
{
	// Etape 1 : Concevoir Votre Fonction Construct
	// (Lancé a Chaque Fois que Ce Controller Est Appelé)
	public function __construct()
	{
		// Chargement des Models Systeme
		$this->User = model('App\Models\UserModel', false);
		$this->Group = model('App\Models\GroupModel', false);
		$this->Role = model('App\Models\RoleModel', false);
		$this->Permission = model('App\Models\PermissionModel', false);
		
		// Chargement du/des Models de Votre Addon
		$this->Journal = model('App\Models\Addon_Journal', false);
	}
	// Etape 2 : Concevoir Votre Fonction Par Défaut
	public function index()
	{
		// Fonction Lancé Par Défaut 
		// (Doit représenter la page central de votre addon)
		// Ecrivez Votre Fonction
		//-----------------------------------------------------------------
		$session = session();
                $user = $this->User->info($session->id);
		$group_list = $this->Group->list();	
		$group = $user['group_id'];
		$role = $user['role_id'];
		if ($group == 1 && $role == 1)
		{
    	$group = "SYSTEM";
    	$role = "ADMIN"; 
		}
		$permission = $this->Permission->get_permission_variant($group, $role);
		$group_list = $this->Group->list_limited($permission['variant']);
		$role_list = $this->Role->list();
		$journal_list = $this->Journal->read();
		//-----------------------------------------------------------------
		// Ecrivez Le Titre de Votre Page et la View Concerné (sans le .php)
		$app = "Journal";
		$page = "index";
		$titre = "Journal - Index";
		return view('Addons/Journal/index' , ['titre'=>$titre , 'journal_list' => $journal_list , 'group_list' => $group_list , 'role_list' => $role_list , 'app'=>$app , 'page'=>$page]);
	}
	// Etape 3 : Concevoir D'Autres Fonctions
	public function details()
	{
		// Fonction Lancé Par Défaut 
		// (Doit représenter la page central de votre addon)
		// Ecrivez Votre Fonction
		//-----------------------------------------------------------------
		$id = $_REQUEST['id'];
		$journal_data = $this->Journal->advanced_read($id);
		//-----------------------------------------------------------------
		// Ecrivez Le Titre de Votre Page et la View Concerné (sans le .php)
		$app = "Journal";
		$page = "details";
		$titre = "Journal - Index";
		return view('Addons/Journal/details' , ['titre'=>$titre , 'journal_data'=>$journal_data , 'app'=>$app , 'page'=>$page]);
	}
	// Exemple de Fonction (Script) Aucune Page View (DOIT REDIRIGER VERS UNE AUTRE FONCTION)
	public function add_journal_data()
	{
		// Ecrivez Votre Fonction
		//-----------------------------------------------------------------
			$session = session();
			$user = $this->User->info($_REQUEST['user_id']);
			$name = $_REQUEST['name'];
			$first_name = $user['first_name'];
			$last_name = $user['last_name'];
			$user_name = "$first_name $last_name";
			$group = $user['group_id'];
			$user2 = $this->User->info($session->id);
			$first_name = $user2['first_name'];
			$last_name = $user2['last_name'];
			$writer_name = "$first_name $last_name";
            $date = $_REQUEST['date'];
        	$details =$_REQUEST['details'];
			$this->Journal->write($name,$group,$user_name,$writer_name,$date,$details);

		//-----------------------------------------------------------------
		// Ecrivez La Fonction de Redirection
		return $this->index();
	}
	// Exemple de Fonction (View) Retourne Une Page View
	public function editor()
	{
		// Ecrivez Votre Fonction
		//-----------------------------------------------------------------
		$session = session();
		$writer_info = $this->User->info($session->id);
		$user_list = $this->User->list();
		$group_list = $this->Group->list();
		$role_list = $this->Role->list();
		//-----------------------------------------------------------------
		// Ecrivez Le Titre de Votre Page et la View Concerné (sans le .php)
		$app = "Journal";
		$page = "editor";
		$titre = "Journal - Ajout d'un Element";
		return view('Addons/Journal/editor' , ['titre'=>$titre , 'app'=>$app , 'page'=>$page , 'writer_info'=>$writer_info , 'user_list'=>$user_list , 'role_list'=>$role_list , 'group_list'=>$group_list]);
	}
}