<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Journal extends Migration
{
	protected $DBGroup = 'addon';
	public function up()
	{
		//
		$this->forge->addField([
			'id'          => [
				'type'           => 'INT',
				'unsigned'       => true,
				'auto_increment' => true,
		],
			'name'       => [
				'type'       => 'VARCHAR',
				'constraint' => '100',
			],
			'writer_name'       => [
				'type'       => 'VARCHAR',
				'constraint' => '100',
			],

			'user_name'         => [
				'type'       => 'VARCHAR',
				'constraint' => '100',
			],
			'group'         => [
				'type'       => 'VARCHAR',
				'constraint' => '100',
			],

			'date'       => [
				'type'       => 'VARCHAR',
				'constraint' => '50',
			],

			'details'       => [
				'type'       => 'VARCHAR',
				'constraint' => '50',
			],
	]);
	$this->forge->addKey('id', true);
	$this->forge->createTable('journal');
	$db = \Config\Database::connect('default');
	$builder = $db->table('permission');
	$data = [
		'name' => 'Read_Journal',
		'app'  => 'Journal',
		'page'  => 'index',
		'variant' => '',
		'group'  => 'SYSTEM',
		'role'  => 'ADMIN',
		'type'  => 'SYSTEM',
	];
	$builder->insert($data);
	$data = [
		'name' => 'Write_Journal',
		'app'  => 'Journal',
		'page'  => 'editor',
		'variant' => '',
		'group'  => 'SYSTEM',
		'role'  => 'ADMIN',
		'type'  => 'SYSTEM',
	];
	$builder->insert($data);
		// GESTION DES PAGES
		$builder = $db->table('apppage');
		// ---------------------------------
		$data = [
			'app_name'  => 'Journal',
			'page'  => 'index',
			'shortcut_name' => 'Journal',
		];
		$builder->insert($data);
		$data = [
			'app_name'  => 'Journal',
			'page'  => 'editor',
			'shortcut_name' => 'Editeur de Journal',	
		];
		$builder->insert($data);
		// ---------------------------------
	}
	public function down()
	{
		//
		$this->forge->dropTable('Journal');
		$db = \Config\Database::connect('default');
		$builder = $db->table('permission');
		$builder->delete(['app' => "Journal"]);
	}
}
