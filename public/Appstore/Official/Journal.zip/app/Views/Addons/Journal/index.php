<?= $this->extend('templates/default') ?>
<?= $this->section('content') ?>
                <div class="container-fluid">
                    <h3 class="text-center text-dark mb-4">Journal</h3>
                    <div class="card shadow">
                        <div class="card-header py-3">
                            <p class="text-primary m-0 fw-bold">Informations du Journal</p>
                            <form method="POST">
                <select class="form-select" name="group_search">
                    <?php
                    if ($group_list != NULL) {
                        foreach ($group_list as $group) {
                            if ($group['id'] != 1) {
                                $id = $group['id'];
                                $group_name_list = array_column($group_list, 'name', 'id');
                                $group_variant_list = array_column($group_list, 'link_name', 'id');
                                $role_name_list = array_column($role_list, 'name', 'id');
                                $group = $group_name_list["$id"];
                                $group_variant = $group_variant_list["$id"];
                                if ($group == $group_variant) {
                                    $group_perm = "$group";
                                } else {
                                    $group_perm = "$group_variant $group ";
                                }
                    ?>
                                <option value="<?= $id ?>"><?= "$group_perm" ?></option>
                    <?php
                            }
                        }
                    }
                    ?>
                </select>
                <button class="btn btn-primary" type="submit" style="width: 100%;">Rechercher</button>
            </form>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive table mt-2" id="dataTable" role="grid" aria-describedby="dataTable_info">
                                <table class="table my-0" id="dataTable">
                                    <thead>
                                        <tr>
                                            <th>Ecrit Par</th>
                                            <th>Résumé</th>
                                            <th>Utilisateur Concerné</th>
                                            <th>Date de L'Envoi</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    if (!isset($_REQUEST['group_search']))
                                    {
                                       $group_search = 0; 
                                    }
                                    else
                                    {
                                        $group_search = $_REQUEST['group_search'];
                                    }
                                    if ($journal_list != NULL) {
                                        foreach ($journal_list as $journal) {
                                                if ($journal['group'] == $group_search) {
                                                    $event_id = $journal['id'];
                                                    $name = $journal['name'];
                                                    $group = $journal['group'];
                                                    $user = $journal['user_name'];
                                                    $writer = $journal['writer_name'];
                                                    $date = $journal['date'];
                                                    $details = $journal['details'];
                                    ?>
                                        <tr>
                                            <td><?=$writer?></td>
                                            <td><?=$name?></td>
                                            <td><?=$user?></td>
                                            <td><?=$date?></td>
                                            <td><form method=POST action=/Addon_Journal/details><input type="hidden" id="id" name="id" value="<?= $event_id ?>"><button class="btn btn-primary" type="submit">Acceder aux Détails</button></form></td>
                                        </tr>
                                        <?php
                                        }}}
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?= $this->endSection() ?>