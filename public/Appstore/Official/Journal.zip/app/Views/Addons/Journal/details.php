<?= $this->extend('templates/default') ?>
<?= $this->section('content') ?>
<?php
$event_id = $journal_data['id'];
$name = $journal_data['name'];
$group = $journal_data['group'];
$user = $journal_data['user_name'];
$writer = $journal_data['writer_name'];
$date = $journal_data['date'];
$details = $journal_data['details'];
?>
                <div class="container-fluid">
                    <h3 class="text-dark mb-4">Journal</h3>
                    <div class="row mb-3">
                        <div class="col-lg-12 col-xl-12">
                            <div class="row">
                                <div class="col">
                                    <div class="card shadow mb-3">
                                        <div class="card-header py-3">
                                            <p class="text-primary m-0 fw-bold">Détail de L'Evenement</p>
                                        </div>
                                        <div class="card-body">
                                            <form>
                                                <div class="row">
                                                    <div class="col">
                                                        <div class="mb-3">
                                                        <label class="form-label" for="username"><strong>Résumé</strong><br></label>
                                                        <p><?=$name?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col">
                                                        <div class="mb-3"><label class="form-label" for="first_name"><strong>Utilisateur Concerné</strong><br></label></div>
                                                        <p><?=$user?></p>
                                                    </div>
                                                    <div class="col">
                                                        <div class="mb-3"><label class="form-label" for="last_name"><strong>Date et Heure</strong></label></div>
                                                        <p><?=$date?></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col">
                                                        <div class="mb-3"><label class="form-label" for="username"><strong>Description</strong><br></label></div>
                                                        <p><?=$details?></p>
                                                    </div>
                                                </div>
                                                <div class="mb-3"><a class="btn btn-primary btn-sm" role="button" style="width: 100%;" href="/Addon_Journal/index">Revenir au Journal</a></div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow mb-5"></div>
                </div>
            </div>
            <?= $this->endSection() ?>