<?= $this->extend('templates/default') ?>
<?= $this->section('content') ?>
<div class="container-fluid">
    <center>
        <h3 class="text-dark mb-4">Gestion du Journal</h3>
    </center>
    <div class="row mb-3">
        <div class="col-lg-12 col-xl-12">
            <div class="row">
                <div class="col">
                    <div class="card shadow mb-3">
                        <div class="card-header py-3">
                            <p class="text-primary m-0 fw-bold">Ajout d'un Element au Journal</p>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="/Addon_Journal/add_journal_data">
                                <div class="row">
                                    <div class="col">
                                        <div class="mb-3"><label class="form-label" for="name"><strong>Information Principal</strong><br></label><input required class="form-control" type="text" id="name" placeholder="Résumé" name="name"></div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <div class="mb-3"><label class="form-label" for="user_id"><strong>Utilisateur Concerné</strong><br></label>
                                            <select class="form-select" name="user_id">
                                                <?php
                                                if ($group_list != NULL) {
                                                    foreach ($group_list as $group) {
                                                        if ($group['id'] != 1) {
                                                            $id = $group['id'];
                                                            $group_name_list = array_column($group_list, 'name', 'id');
                                                            $group_variant_list = array_column($group_list, 'link_name', 'id');
                                                            $group = $group_name_list["$id"];
                                                            $group_variant = $group_variant_list["$id"];
                                                            if ($group == $group_variant) {
                                                                $group_perm = "$group";
                                                            } else {
                                                                $group_perm = "$group_variant $group ";
                                                            }
                                                ?>
                                                            <optgroup label="<?= $group_perm ?>">
                                                                <?php
                                                                if ($user_list != NULL) {
                                                                    foreach ($user_list as $user) {
                                                                        if ($user['id'] != 1) {
                                                                            if ($user['group_id'] == $id) {
                                                                                $role_id = $writer_info['role_id'];
                                                                                $role_hierarchy = array_column($role_list, 'hierarchy', 'id');
                                                                                $role = $role_hierarchy["$role_id"];
                                                                                if ($user['role_id'] > $role) {
                                                                                    $id = $user['id'];
                                                                                    $nom = $user['first_name'];
                                                                                    $prenom = $user['last_name'];
                                                                ?>
                                                                                    <option value="<?php echo $id ?>" selected=""><?php echo $nom ?> <?php echo $prenom ?></option>
                                                                    <?php
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                                    ?>
                                                            </optgroup>
                                            <?php
                                                            }
                                                        }
                                                    }
                                            ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="mb-3"><label class="form-label" for="date"><strong>Date et Heure</strong></label><input required class="form-control" id="date" name="date" placeholder="Doe" name="Date" type="date"></div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <div class="mb-3"><label class="form-label" for="details"><strong>Description</strong><br></label><textarea required id="details" name="details" class="form-control"></textarea></div>
                                    </div>
                                </div>
                                <div class="mb-3"><button class="btn btn-primary btn-sm" type="submit" style="width: 100%;">Envoyer</button></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card shadow mb-5"></div>
</div>
</div>
<?= $this->endSection() ?>