<?php

namespace App\Models;

use CodeIgniter\Model;

class Addon_Journal extends Model
{
    // NE PAS TOUCHER
    protected $DBGroup = 'addon';
    // -----------

    // Ecrire Le Nom de Votre Table
    protected $table      = 'journal';
    // ---------------------------------

    protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
    protected $useSoftDeletes = false;

    // Liste des Données Autorisé en Entrée et Sortie 
    // (Y Placer Toute Les Valeurs de Votre Table SQL)
    protected $allowedFields = ['id','name','writer_name','user_name','group','date','details'];

    // Fonction Vide
    public function read()
    {
        // Inserer La Procedure Lié a Cette Fonction
        return $this->findall();
    }
    public function advanced_read($id)
    {
        // Inserer La Procedure Lié a Cette Fonction
        return $this->where('id', $id)->first();
    }
    public function write($name,$group,$user_name,$writer_name,$date,$details)
    {
        $data = [
            'name' => $name,
            'group' => $group,
            'user_name'  => $user_name,
            'writer_name'  => $writer_name,
            'date' => $date,
            'details'  => $details,
        ];
        $this->insert($data);
    }
}