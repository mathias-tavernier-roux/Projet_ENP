<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Incident extends Migration
{
	protected $DBGroup = 'addon';
	public function up()
	{
		//
		$this->forge->addField([
			'id'          => [
				'type'           => 'INT',
				'unsigned'       => true,
				'auto_increment' => true,
		],
			'name'       => [
				'type'       => 'VARCHAR',
				'constraint' => '100',
			],
			'writer_name'       => [
				'type'       => 'VARCHAR',
				'constraint' => '100',
			],

			'user_name'         => [
				'type'       => 'VARCHAR',
				'constraint' => '100',
			],
			'group'         => [
				'type'       => 'VARCHAR',
				'constraint' => '100',
			],

			'date'       => [
				'type'       => 'VARCHAR',
				'constraint' => '50',
			],

			'details'       => [
				'type'       => 'VARCHAR',
				'constraint' => '50',
			],
			'NDC'       => [
				'type'       => 'VARCHAR',
				'constraint' => '100',
				'default' => 'N/A'
			],
			'etat'       => [
				'type'       => 'VARCHAR',
				'constraint' => '100',
				'default' => 'N/A',
			],
			'resolver_id'       => [
				'type'       => 'VARCHAR',
				'constraint' => '100',
				'default' => 'N/A',
			],
			'resolver_name'       => [
				'type'       => 'VARCHAR',
				'constraint' => '100',
				'default' => 'N/A',
			],

	]);
	$this->forge->addKey('id', true);
	$this->forge->createTable('incident');
	$db = \Config\Database::connect('default');
	$builder = $db->table('permission');
	$data = [
		'name' => 'Read_Incidents',
		'app'  => 'Incident',
		'page'  => 'index',
		'variant' => '',
		'group'  => 'SYSTEM',
		'role'  => 'ADMIN',
		'type'  => 'SYSTEM',
	];
	$builder->insert($data);
	$data = [
		'name' => 'Write_Incidents',
		'app'  => 'Incident',
		'page'  => 'editor',
		'variant' => '',
		'group'  => 'SYSTEM',
		'role'  => 'ADMIN',
		'type'  => 'SYSTEM',
	];
	$builder->insert($data);
	$data = [
		'name' => 'SelfReport_Incidents',
		'app'  => 'Incident',
		'page'  => 'self_report_form',
		'variant' => '',
		'group'  => 'SYSTEM',
		'role'  => 'ADMIN',
		'type'  => 'SYSTEM',
	];
	$builder->insert($data);
	$data = [
		'name' => 'Read_Confirmed_Incidents',
		'app'  => 'Incident',
		'page'  => 'list_confirmed',
		'variant' => '',
		'group'  => 'SYSTEM',
		'role'  => 'ADMIN',
		'type'  => 'SYSTEM',
	];
	$builder->insert($data);
	$data = [
		'name' => 'Read_Resolved_Incidents',
		'app'  => 'Incident',
		'page'  => 'list_resolved',
		'variant' => '',
		'group'  => 'SYSTEM',
		'role'  => 'ADMIN',
		'type'  => 'SYSTEM',
	];
	$builder->insert($data);
		// GESTION DES PAGES
		$builder = $db->table('apppage');
		// ---------------------------------
		$data = [
			'app_name'  => 'Incident',
			'page'  => 'index',
			'shortcut_name' => 'Liste des Incidents A Verifier',
		];
		$builder->insert($data);
		$data = [
			'app_name'  => 'Incident',
			'page'  => 'list_confirmed',
			'shortcut_name' => 'Liste des Incidents a Traiter',
		];
		$builder->insert($data);
		$data = [
			'app_name'  => 'Incident',
			'page'  => 'list_confirmed',
			'shortcut_name' => 'Liste des Incidents Résolu',
		];
		$builder->insert($data);
		$data = [
			'app_name'  => 'Incident',
			'page'  => 'editor',
			'shortcut_name' => 'Ajouter un Incident',
			
		];
		$builder->insert($data);
		$data = [
			'app_name'  => 'Incident',
			'page'  => 'self_report_form',
			'shortcut_name' => 'Formulaire Auto Rapport (Jeune)',
			
		];
		$builder->insert($data);
		// ---------------------------------
	}
	public function down()
	{
		//
		$this->forge->dropTable('Incident');
		$db = \Config\Database::connect('default');
		$builder = $db->table('permission');
		$builder->delete(['app' => "Incident"]);
	}
}
