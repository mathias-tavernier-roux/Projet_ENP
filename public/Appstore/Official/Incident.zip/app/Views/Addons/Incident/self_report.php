<?= $this->extend('templates/default') ?>
<?= $this->section('content') ?>
<div class="container-fluid">
    <center>
        <h3 class="text-dark mb-4">Gestion des Incidents</h3>
    </center>
    <div class="row mb-3">
        <div class="col-lg-12 col-xl-12">
            <div class="row">
                <div class="col">
                    <div class="card shadow mb-3">
                        <div class="card-header py-3">
                            <p class="text-primary m-0 fw-bold">Signaler un Incident (Panne ou Probleme)</p>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="/Addon_Incident/self_report">
                                <div class="row">
                                    <div class="col">
                                        <div class="mb-3"><label class="form-label" for="name"><strong>Information Principal</strong><br></label><input required class="form-control" type="text" id="name" placeholder="Résumé" name="name"></div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <div class="mb-3"><label class="form-label" for="date"><strong>Date de l'incident</strong></label><input required class="form-control" id="date" name="date" placeholder="Doe" name="Date" type="date"></div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <div class="mb-3"><label class="form-label" for="details"><strong>Description</strong><br></label><textarea required id="details" name="details" class="form-control"></textarea></div>
                                    </div>
                                </div>
                                <div class="mb-3"><button class="btn btn-primary btn-sm" type="submit" style="width: 100%;">Envoyer</button></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card shadow mb-5"></div>
</div>
</div>
<?= $this->endSection() ?>