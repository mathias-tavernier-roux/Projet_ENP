<?= $this->extend('templates/default') ?>
<?= $this->section('content') ?>
<?php
$event_id = $incident_data['id'];
$name = $incident_data['name'];
$group = $incident_data['group'];
$user = $incident_data['user_name'];
$writer = $incident_data['writer_name'];
$date = $incident_data['date'];
$details = $incident_data['details'];
$NDC = $incident_data['NDC'];
if ($NDC == "1") {
    $NDC = "Leger (Traitement des que Possible)";
}
if ($NDC == "2") {
    $NDC = "Modéré (Traitement Dans Le Mois)";
}
if ($NDC == "3") {
    $NDC = "Grave (Traitement Dans La Semaine)";
}
if ($NDC == "4") {
    $NDC = "IMPORTANT (Traitement Dans Les 3 Jours)";
}
if ($NDC == "5") {
    $NDC = "CRITIQUE (Traitement J+1)";
}
?>
<div class="container-fluid">
    <center><h3 class="text-dark mb-4">Incidents</h3></center>
    <div class="row mb-3">
        <div class="col-lg-12 col-xl-12">
            <div class="row">
                <div class="col">
                    <div class="card shadow mb-3">
                        <div class="card-header py-3">
                            <p class="text-primary m-0 fw-bold">Détail de Incident</p>
                        </div>
                        <div class="card-body">
                            <form>
                                <div class="row">
                                    <div class="col">
                                        <div class="mb-3"><label class="form-label" for="résumé"><strong>Résumé</strong><br /></label></div>
                                        <p>Information Principal</p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <div class="mb-3"><label class="form-label" for="user"><strong>Utilisateur Concerné</strong><br /></label></div>
                                        <p><?=$user?></p>
                                    </div>
                                    <div class="col">
                                        <div class="mb-3"><label class="form-label" for="date"><strong>Date</strong></label></div>
                                        <p>01/21/2020</p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <div class="mb-3"><label class="form-label" for="ndc"><strong>Criticité</strong><br /></label></div>
                                        <p><strong>Niveau <?= $NDC ?></strong></p>
                                        <p></p>
                                    </div>
                                </div>
                                <div class="mb-3"><button class="btn btn-primary btn-sm" type="submit" style="width: 100%;">Revenir au incident</button></div>
                            </form>
                            <?php
                            if ($etat == "3") {
                            ?>
                            <p>Attention : en cliquant sur ce bouton vous confirmez que l'incident a été traité et que l'element / les elements concerné a été réparé</p>
                            <p>Votre Identifiant Utilisateur est enregistré dans la requete</p>
                            <form method=POST action=/Addon_Incident/details><input type="hidden" id="id" name="id" value="<?= $event_id ?>"><button class="btn btn-primary" type="submit">Confirmer que l'incident a été traité</button></form>
                            <?php
                            }
                            ?>
                        </div>
                    </div>
                    <?php
                    if ($NDC == "N/A") {
                    ?>
                        <div class="card shadow mb-3">
                            <div class="card-header py-3">
                                <p class="text-primary m-0 fw-bold">Choisissez L'Importance de l'incident</p>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="/Addon_Incident/check">
                                    <input type="hidden" id="id" name="id" value="<?= $event_id ?>">
                                    <div class="row">
                                        <div class="col">
                                            <div class="mb-3"></div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col">
                                            <select class="form-select" name="NDC">
                                                <option value="1">Leger (Traitement des que Possible)</option>
                                                <option value="2">Modéré (Traitement Dans Le Mois)</option>
                                                <option value="3">Grave (Traitement Dans La Semaine)</option>
                                                <option value="4">IMPORTANT (Traitement Dans Les 3 Jours)</option>
                                                <option value="5">CRITIQUE (Traitement J+1)</option>
                                            </select>
                                        </div>
                                        <div class="mb-3"><button class="btn btn-primary btn-sm" type="submit" style="width: 100%;">Envoyer</button></div>
                                </form>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
    <div class="card shadow mb-5"></div>
</div>
</div>
<?= $this->endSection() ?>