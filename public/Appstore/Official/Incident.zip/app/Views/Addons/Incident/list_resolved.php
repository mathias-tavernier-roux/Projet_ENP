﻿<?= $this->extend('templates/default') ?>
<?= $this->section('content') ?>
<div class="container-fluid">
    <center>
        <h3 class="text-center text-dark mb-4">Incidents</h3>
    </center>
    <div class="card shadow">
        <div class="card-header py-3">
            <p class="text-primary m-0 fw-bold">Liste des Incidents</p>
        </div>
        <div class="card-body">
            <div class="table-responsive table mt-2" id="dataTable" role="grid" aria-describedby="dataTable_info">
                <table class="table my-0" id="dataTable">
                    <thead>
                        <tr>
                            <th>Ecrit Par</th>
                            <th>Résumé</th>
                            <th>Utilisateur Concerné</th>
                            <th>Date de L'Envoi</th>
			    <th>Resolu par :</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($incident_list != NULL) {
                            foreach ($incident_list as $incident) {
                                if ($incident['etat'] == "3") {
                                    $event_id = $incident['id'];
                                    $name = $incident['name'];
                                    $group = $incident['group'];
                                    $user = $incident['user_name'];
                                    $writer = $incident['writer_name'];
                                    $date = $incident['date'];
                                    $details = $incident['details'];
                                    $resolver_id = $incident['resolver_id'];
                                    $resolver_name = $incident['resolver_name'];
                        ?>
                                    <tr>
                                        <td><?= $writer ?></td>
                                        <td><?= $name ?></td>
                                        <td><?= $user ?></td>
                                        <td><?= $date ?></td>
                                        <td><?= $resolver_id ?> | <?= $resolver_name ?></td>
                                        <td>
                                            <form method=POST action=/Addon_Incident/details><input type="hidden" id="id" name="id" value="<?= $event_id ?>"><button class="btn btn-primary" type="submit">Acceder aux Détails</button></form>
                                        </td>
                                    </tr>
                        <?php
                                }
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
<?= $this->endSection() ?>