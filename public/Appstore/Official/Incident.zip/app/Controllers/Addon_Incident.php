<?php

namespace App\Controllers;

class Addon_Incident extends BaseController
{
	// Etape 1 : Concevoir Votre Fonction Construct
	// (Lancé a Chaque Fois que Ce Controller Est Appelé)
	public function __construct()
	{
		// Chargement des Models Systeme
		$this->User = model('App\Models\UserModel', false);
		$this->Group = model('App\Models\GroupModel', false);
		$this->Role = model('App\Models\RoleModel', false);
		$this->Permission = model('App\Models\PermissionModel', false);
		
		// Chargement du/des Models de Votre Addon
		$this->Incident = model('App\Models\Addon_Incident', false);
	}
	// Etape 2 : Concevoir Votre Fonction Par Défaut
	public function index()
	{
		// Fonction Lancé Par Défaut 
		// (Doit représenter la page central de votre addon)
		// Ecrivez Votre Fonction
		//-----------------------------------------------------------------
		$session = session();
        $user = $this->User->info($session->id);
		$group_list = $this->Group->list();	
		$group = $user['group_id'];
		$role = $user['role_id'];
		if ($group == 1 && $role == 1)
		{
    	$group = "SYSTEM";
    	$role = "ADMIN"; 
		}
		$permission = $this->Permission->get_permission_variant($group, $role);
		$group_list = $this->Group->list_limited($permission['variant']);
		$role_list = $this->Role->list();
		$incident_list = $this->Incident->read();
		//-----------------------------------------------------------------
		// Ecrivez Le Titre de Votre Page et la View Concerné (sans le .php)
		$app = "Incident";
		$page = "index";
		$titre = "Incident - Liste";
		return view('Addons/Incident/index' , ['titre'=>$titre , 'incident_list' => $incident_list , 'group_list' => $group_list , 'role_list' => $role_list , 'app'=>$app , 'page'=>$page]);
	}
	// Etape 3 : Concevoir D'Autres Fonctions
	public function list_confirmed()
	{
		// Fonction Lancé Par Défaut 
		// (Doit représenter la page central de votre addon)
		// Ecrivez Votre Fonction
		//-----------------------------------------------------------------
		$session = session();
        $user = $this->User->info($session->id);
		$group_list = $this->Group->list();	
		$group = $user['group_id'];
		$role = $user['role_id'];
		if ($group == 1 && $role == 1)
		{
    	$group = "SYSTEM";
    	$role = "ADMIN"; 
		}
		$incident_list = $this->Incident->read();
		//-----------------------------------------------------------------
		// Ecrivez Le Titre de Votre Page et la View Concerné (sans le .php)
		$app = "Incident";
		$page = "list_confirmed";
		$titre = "Incident - Liste";
		return view('Addons/Incident/list_confirmed' , ['titre'=>$titre , 'incident_list' => $incident_list, 'app'=>$app , 'page'=>$page]);
	}
	public function details()
	{
		// Fonction Lancé Par Défaut 
		// (Doit représenter la page central de votre addon)
		// Ecrivez Votre Fonction
		//-----------------------------------------------------------------
		$id = $_REQUEST['id'];
		$incident_data = $this->Incident->advanced_read($id);
		//-----------------------------------------------------------------
		// Ecrivez Le Titre de Votre Page et la View Concerné (sans le .php)
		$app = "Incident";
		$page = "details";
		$titre = "Incidents - Informations Complémentaire";
		return view('Addons/Incident/details' , ['titre'=>$titre , 'incident_data'=>$incident_data , 'app'=>$app , 'page'=>$page]);
	}
	// Exemple de Fonction (Script) Aucune Page View (DOIT REDIRIGER VERS UNE AUTRE FONCTION)
	public function add_incident()
	{
		// Ecrivez Votre Fonction
		//-----------------------------------------------------------------
			$session = session();
			$user = $this->User->info($_REQUEST['user_id']);
			$name = $_REQUEST['name'];
			$first_name = $user['first_name'];
			$last_name = $user['last_name'];
			$user_name = "$first_name $last_name";
			$group = $user['group_id'];
			$user2 = $this->User->info($session->id);
			$first_name = $user2['first_name'];
			$last_name = $user2['last_name'];
			$writer_name = "$first_name $last_name";
            $date = $_REQUEST['date'];
        	$details =$_REQUEST['details'];
			$this->Incident->write($name,$group,$user_name,$writer_name,$date,$details);

		//-----------------------------------------------------------------
		// Ecrivez La Fonction de Redirection
		return $this->index();
	}
	public function self_report()
	{
		// Ecrivez Votre Fonction
		//-----------------------------------------------------------------
			$session = session();
			$user = $this->User->info($session->id);
			$first_name = $user['first_name'];
			$last_name = $user['last_name'];
			$group = $user['group_id'];
			$user_name = "$first_name $last_name";
			$writer_name = "$first_name $last_name";
            $date = $_REQUEST['date'];
        	$details =$_REQUEST['details'];
			$name =$_REQUEST['name'];
			$this->Incident->write($name,$group,$user_name,$writer_name,$date,$details);

		//-----------------------------------------------------------------
		// Ecrivez La Fonction de Redirection
		return $this->index();
	}
	public function check()
	{
		// Ecrivez Votre Fonction
		//-----------------------------------------------------------------
			$id = $_REQUEST['id'];
			$IDC_1 = $_REQUEST['impact'];
			$IDC_2 = $_REQUEST['risque'];
			$IDC = $IDC_1 * $IDC_2;
			$this->Incident->check($id,$IDC,$IDC_1,$IDC_2);
		//-----------------------------------------------------------------
		// Ecrivez La Fonction de Redirection
		return $this->index();
	}
	// Exemple de Fonction (View) Retourne Une Page View
	public function editor()
	{
		// Ecrivez Votre Fonction
		//-----------------------------------------------------------------
		$session = session();
		$writer_info = $this->User->info($session->id);
		$user_list = $this->User->list();
		$group_list = $this->Group->list();
		$role_list = $this->Role->list();
		//-----------------------------------------------------------------
		// Ecrivez Le Titre de Votre Page et la View Concerné (sans le .php)
		$app = "Incident";
		$page = "editor";
		$titre = "Incident - Ajout d'un Element";
		return view('Addons/Incident/editor' , ['titre'=>$titre , 'app'=>$app , 'page'=>$page , 'writer_info'=>$writer_info , 'user_list'=>$user_list , 'role_list'=>$role_list , 'group_list'=>$group_list]);
	}
	public function self_report_form()
	{
		$app = "Incident";
		$page = "self_report_form";
		$titre = "Incident - Formulaire d'Auto Rapport";
		return view('Addons/Incident/self_report' , ['titre'=>$titre , 'app'=>$app , 'page'=>$page]);
	}
}